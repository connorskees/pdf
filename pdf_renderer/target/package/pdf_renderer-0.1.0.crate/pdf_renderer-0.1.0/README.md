# PDF Renderer

Early stage, focused only on well-formed input and Type 1 fonts
